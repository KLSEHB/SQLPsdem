#-*- coding:utf-8 -*-
"""
# Time       ：2022/4/13 20:41 星期三
# Author     ：jiangmc
# version    ：python 3.6
# Description： 从漏洞定位文本向量中提取评测指标
                [FO/SO/N]:Pos_i:testCase:Rule_i:SQL:pageName:toolName:appName
"""
from collections import defaultdict


def extractDefenseIndex(tool, curr_app, rule):
    """
    [(tooName,APPName,testcase)] 6,7,2
    [(appName:SQL:url:pos:FO)] 7, 4, 5, 1, 0,SQL不作为去重，仅作为人工验证
    [(appName:SQL:url:pos:SO)]
    [(toolName, appName, testcase, rule)] 6,7,2,3
    :return:
    """
    path = r"E:/wackopicko.txt"
    defense_res = []
    fo_res = []
    so_res = []
    rule_res = []
    with open(path, encoding='utf-8') as file:
        lines = file.readlines()
        for line in lines:
            try:
                line = line.replace("\n", "").split(" [ming:ming] ")
                if line[5] == "" or line[6] == "":
                    continue
                defense_res.append((line[6], line[7], line[2]))
                rule_res.append((line[6], line[7], line[2], line[3]))
                sql = line[4].replace("''", '').replace("()", "").replace('""', "")
                if line[0] == "FO":
                    fo_res.append((line[7], sql, line[5], line[1], line[0]))
                else:
                    so_res.append((line[7], sql, line[5], line[1], line[0]))
            except Exception as e:
                continue
    res = list(set(defense_res))  # 去重
    res_dict = {}
    fo_dict = defaultdict(int)
    so_dict = defaultdict(int)
    rule_dict = {}
    # 统计各个工具在对应的web应用下的测试用例的个数
    for t in tool:
        for a in curr_app:
            res_dict[t+"_"+a] = 0
    for r in res:
        try:
            res_dict[r[0]+"_"+r[1]] += 1
        except:
            continue
    print("..........统计防御率..........")
    print(res_dict)
    print("..........统计各个规则的个数..........")
    for t in tool:
        for a in curr_app:
            for r in rule:
                rule_dict[t+"_"+a+"_"+r] = 0
    rule_res = list(set(rule_res))
    for r in rule_res:
        try:
            rule_dict[r[0]+"_"+r[1]+"_"+r[3]] += 1
        except:
            continue
    print(rule_dict)
    print("..........统计一阶SQL注入个数..........")
    fo_res = list(set(fo_res))
    # 展示
    print(fo_res)
    for fo in fo_res:
        fo_dict[fo[0]] += 1
    for key in fo_dict.keys():
        print(key, "==>", fo_dict[key])
    print("..........统计二阶SQL注入个数..........")
    so_res = list(set(so_res))
    print(so_res)
    for so in so_res:
        so_dict[so[0]] += 1
    for key in so_dict.keys():
        print(key, "==>", so_dict[key])


if __name__ == '__main__':
    tool = ['sqlmap', 'dsss', 'ssql', 'jsqli']
    app = ['dvwa', 'pikachu', 'bwapp', 'sqlilabs', 'schoolmate', 'faqforge', 'wackopicko', 'myblog', 'webchess',
           'covid', 'doctormms', 'petshop']
    curr_app = ['wackopicko']
    rule = ["Rule1", "Rule2", "Rule3", "Rule4", "Rule5"]
    extractDefenseIndex(tool, curr_app, rule)