#!/usr/bin/env python
# -*- coding: utf-8 -*-
# @Time    : 2021/5/14 9:32
# @Author  : ming
# @E-mail  : 991027961@qq.com
# @File    : soi_4.py
# @Software: PyCharm
# ---------------------------------------------------------------------------------------------
# @description：二阶注入静态分析阶段，找到可能会形成注入的点，并按顺序进行标记
#               1.定位SQL语句
#               2.获取含有SEPs字句，对其进行划分，然后对每一个SEP进行是否可能存在注入的判断
#               3.对2中的查找的的条件按顺序添加策略标记(0:无入口 1:策略1 2:策略2)
#               4.修改源文件，确保源文件不会产生错误
# ---------------------------------------------------------------------------------------------
# 静态分析阶段：version2021.3.0
# 根据论文描述构建的测试代码
# 针对myblog, 在SQL上添加标记
# ---------------------------------------------------------------------------------------------
import hashlib
import re
import chardet
import os

# 修改文件的编码
def updateEncode(path):
    try:
        with open(path, 'rb+') as fp:
            content = fp.read()
            codeType = chardet.detect(content)['encoding']
            if codeType == None:
                return
            content = content.decode(codeType, "ignore").encode("UTF-8")
            fp.seek(0)
            fp.write(content)
    except Exception as e:
        print("------编码出现错误------")
        print(e)


# 获取所有的PHP文件
def getFileName(basedir):
    dirs = os.listdir(basedir)
    for dir in dirs:
        path = os.path.join(basedir, dir)
        # 处理文件夹，递归处理
        if os.path.isdir(path):
            getFileName(path)
        # 处理普通文件
        elif os.path.isfile(path):
            # 只处理后缀为.php的文件和处理faqforge的inc文件
            if os.path.splitext(path)[-1] == ".php" or os.path.splitext(path)[-1] == ".inc":
                # print("正在给文件->", path, "<-添加标识符......")
                # 对于某些web应用，使用<??>简短形式，启用下面代码，标准的为<?php?>，主要为了适配PHP-parser进行解析
                # with open(path, 'r', encoding='utf-8') as file:
                #     lines = file.readlines()
                #     if not lines[0].lstrip().startswith("<?php"):
                #         lines[0] = lines[0].replace("<?", "<?php", 1)
                #     total = "".join(lines)
                # with open(path, 'w', encoding='utf-8') as file:
                #     file.write(total)
                # 清除注释
                clearComment(path)
                # 修改文件的编码
                updateEncode(path)
                # 更新源代码并添加标识符
                updateFile(path)
                addIdentifier(path)
            # print("文件->", path, "<-添加标识符完毕......")


# 清除注释
def clearComment(filename):
    command = r"php C:/Users/admin/Desktop/vendor/nikic/php-parser/bin/php-parse-1 -mode=1 {fname}".format(fname=filename)
    po = os.popen(command)
    print(po.buffer.read().decode(encoding='utf-8', errors='ignore'))
    po.close()


# 区分变量，判断采用策略1 一阶、还是策略2  二阶
def judgeVar(flag, text, SQLPostioionStack, var):
    if var == "$_POST" or var == "$_GET" or var == "$_REQUEST" or var == "$this":  # 说明此时取值绝对是间接变量
        print(var, "的数据来源：", var)
        flag += "_1"
    elif var == "$_COOKIE" or var == "$_SESSION" or var == "$_FILES":  # 说明此时取值绝对是间接变量
        print(var, "的数据来源：", var)
        flag += "_2"
    else:
        judge = -1  # 设置默认策略为位置
        # 在上下文中查找，判断其所属
        isFind = False
        for idx in range(len(SQLPostioionStack) - 2, -1, -1):
            tmp = text[SQLPostioionStack[idx]: SQLPostioionStack[idx + 1]]
            lines = re.findall(r"\$" + var[1:] + "\s*?=(.+?);[\n\t\s]", tmp, re.IGNORECASE | re.S)
            if len(lines) > 0:
                for line in lines:
                    if re.search(r"\$_POST|\$_GET|\$_REQUEST", line, re.IGNORECASE | re.S):
                        print(var, "的数据来源：", line)
                        judge = 1
                        isFind = True
                        break
                    elif re.search(r"[^\"']*mysql_real_escape_string\(.+?\)", line, re.IGNORECASE | re.S):
                        print(var, "的数据来源：", line)
                        judge = 1
                        isFind = True
                        break
                    elif re.search(r"[^\"']*mysql[i]?_[a-z_]+\(.+?\)", line, re.IGNORECASE | re.S) or re.search(
                            r"[^\"']*sql_[a-z_]+\(.+?\)", line, re.IGNORECASE | re.S):
                        print(var, "的数据来源：", line)
                        judge = 2
                        isFind = True
                        break
                    elif re.search(r"\$_COOKIE|\$_SESSION", line, re.IGNORECASE | re.S):
                        print(var, "的数据来源：", line)
                        judge = 2
                        isFind = True
                        break
            if isFind:
                break
        if not isFind:
            print(var, "的数据来源是通过形参传递的,置为默认值0")
        if judge == 1:
            flag += "_1"
        elif judge == 2:
            flag += "_2"
        else:
            flag += "_0"
    return flag


# 添加操作符标记  修改
def addOperator(str, inner):
    if re.search("\slike", str, re.IGNORECASE | re.S):
        str = re.sub("\slike", inner + "_like_" + inner, str, flags=re.IGNORECASE | re.S)
    elif re.search("\sin", str, re.IGNORECASE | re.S):
        str = re.sub("\sin", inner + "_in_" + inner, str, flags=re.IGNORECASE | re.S)
    elif re.search("\srlike", str, re.IGNORECASE | re.S):
        str = re.sub("\srlike", inner + "_rlike_" + inner, str, flags=re.IGNORECASE | re.S)
    elif re.search("\sbetween", str, re.IGNORECASE | re.S):
        str = re.sub("\sbetween", " __in__ ", str, flags=re.IGNORECASE | re.S)
    elif re.search("[^\!\>\<]\=", str, re.IGNORECASE | re.S):
        str = re.sub("\=", " " + inner + "_=_" + inner + " ", str, flags=re.IGNORECASE | re.S)
    elif re.search("\<\>", str, re.IGNORECASE | re.S):
        str = re.sub("\<\>", " " + inner + "_<>_" + inner + " ", str, flags=re.IGNORECASE | re.S)
    elif re.search("\!\=", str, re.IGNORECASE | re.S):
        str = re.sub("\!\=", " " + inner + "_!=_" + inner + " ", str, flags=re.IGNORECASE | re.S)
    elif re.search("\<\=", str, re.IGNORECASE | re.S):
        str = re.sub("\<\=", " " + inner + "_<=_" + inner + " ", str, flags=re.IGNORECASE | re.S)
    elif re.search("\>\=", str, re.IGNORECASE | re.S):
        str = re.sub("\>\=", " " + inner + "_>=_" + inner + " ", str, flags=re.IGNORECASE | re.S)
    elif re.search("[^<]\>", str, re.IGNORECASE | re.S):
        str = re.sub("\>", " " + inner + "_>_" + inner + " ", str, flags=re.IGNORECASE | re.S)
    elif re.search("\<", str, re.IGNORECASE | re.S):
        str = re.sub("\<", " " + inner + "_<_" + inner + " ", str, flags=re.IGNORECASE | re.S)
    return str


# 生成句内标识符
def generateInnerFlag(init: str, pKey: str):
    pKey = eval('0x' + pKey)
    E = hashlib.md5(init.encode('UTF-8')).hexdigest()
    return hex(eval('0x' + E) ^ pKey)[2:]


# select delete划分变量
def selectAndDeleteVarSplit(sql, cond, inner, SQLType):
    tmpinit = sql
    for ele in cond:
        sql = re.sub("\s" + ele + '\s', " " + inner + "_" + ele + "_" + inner + " ", sql, flags=re.IGNORECASE | re.S)
    if tmpinit == sql:
        return sql, [], []
    conn = ['and', 'or']
    for ele in conn:
        sql = re.sub('\s' + ele + '\s', " " + inner + "_" + ele + "_" + inner + " ", sql, flags=re.IGNORECASE | re.S)
    oper = ['>=', '<=', '<>', '>', '<', '=', '!=', 'like', 'rlike', 'in', 'between', 'is']
    newOper = ['>=', '<=', '<>', '[^<-]>[^=]', '<[^>=]', '[^><!]=', '!=', '\slike\s', '\srlike\s', '\sin\s',
               '\sbetween\s', '\sis\s']
    for i, ele in enumerate(newOper):
        if ele == '[^<-]>[^=]':
            p = list(set(re.findall(ele, sql, flags=re.IGNORECASE | re.S)))
            for m in p:
                sql = sql.replace(m, m[0] + " " + inner + "_" + oper[i] + "_" + inner + " " + m[-1])
            # sql = re.sub(m, m[0] + " " + inner + "_" + oper[i] + "_" + inner + " " + m[-1], sql, flags=re.IGNORECASE | re.S)
        elif ele == '<[^>=]':
            p = list(set(re.findall(ele, sql, flags=re.IGNORECASE | re.S)))
            for m in p:
                sql = sql.replace(m, " " + inner + "_" + oper[i] + "_" + inner + " " + m[1])
            # sql = re.sub(m, " " + inner + "_" + oper[i] + "_" + inner + " " + m[1], sql, flags=re.IGNORECASE | re.S)
        elif ele == '[^><!]=':
            p = list(set(re.findall(ele, sql, flags=re.IGNORECASE | re.S)))
            for m in p:
                sql = sql.replace(m, m[0] + " " + inner + "_" + oper[i] + "_" + inner + " ")
            # sql = re.sub(m, m[0] + " " + inner + "_" + oper[i] + "_" + inner + " ", sql, flags=re.IGNORECASE | re.S)
        else:
            sql = re.sub(ele, " " + inner + "_" + oper[i] + "_" + inner + " ", sql, flags=re.IGNORECASE | re.S)
    tmpSQL = sql
    condSplit = []
    begin = 0
    findFlag = []
    for i in range(len(cond)):
        splitSQL = sql.split(inner + "_" + cond[i] + "_" + inner)[-1]
        if splitSQL == sql:
            continue
        else:
            if cond[i] == "order by" or cond[i] == "group by":
                findFlag.append(0)
            else:
                findFlag.append(1)
            sql = splitSQL
            begin = i + 1
            break
    for i in range(begin, len(cond)):
        tmp = sql.split(inner + "_" + cond[i] + "_" + inner)
        if len(tmp) == 2:
            if cond[i] == "order by" or cond[i] == "group by":
                findFlag.append(0)
            else:
                findFlag.append(1)
            condSplit.append(tmp[0])
            sql = tmp[1]
    condSplit.append(sql)
    connSplit = []
    connFindFlag = []
    for i, ele1 in enumerate(condSplit):
        tmp = ele1.split(inner + "_" + conn[0] + "_" + inner)
        for t in tmp:
            mm = t.split(inner + "_" + conn[1] + "_" + inner)
            if findFlag[i] == 1:
                connFindFlag += [1] * len(mm)
            else:
                connFindFlag += [0] * len(mm)
            connSplit += mm
    operSplit = []
    if SQLType == 1:
        # 划分set字句
        operSplit += connSplit[0].split(' ' + inner + "_=_" + inner + " ")[1:]
        connSplit = connSplit[1:]
    for ele1 in connSplit:
        i = 0
        for ele2 in oper:
            i += 1
            tmp = ele1.split(inner + "_" + ele2 + "_" + inner)
            if len(tmp) == 2:
                operSplit.append(tmp[1])
                break
            elif len(oper) == i:
                operSplit.append(ele1)
            elif len(tmp) == 1:
                continue
    if len(connFindFlag) < len(operSplit):
        connFindFlag = [1] * (len(operSplit) - len(connFindFlag)) + connFindFlag
    print("=======", connFindFlag)
    return tmpSQL, operSplit, connFindFlag


# 根据执行SQL函数求出sql
def obtainSQL(sqlStr):
    # 判别类型
    if re.match("mysqli_query", sqlStr, re.IGNORECASE | re.S):
        pos = 2
        sqlStr = re.match("mysqli_query\s*(.+)", sqlStr, re.IGNORECASE | re.S).group(1)
    elif re.match("execute", sqlStr, re.IGNORECASE | re.S):
        pos = 2
        sqlStr = re.match("execute\s*(.+)", sqlStr, re.IGNORECASE | re.S).group(1)
    elif re.match("exec", sqlStr, re.IGNORECASE | re.S):
        pos = 1
        sqlStr = re.match("exec\s*(.+)", sqlStr, re.IGNORECASE | re.S).group(1)
    elif re.match("mysqli_multi_query", sqlStr, re.IGNORECASE | re.S):
        pos = 2
        sqlStr = re.match("mysqli_multi_query\s*(.+)", sqlStr, re.IGNORECASE | re.S).group(1)
    elif re.match("->sql_query", sqlStr, re.IGNORECASE | re.S):
        pos = 1
        sqlStr = re.match("->sql_query\s*(.+)", sqlStr, re.IGNORECASE | re.S).group(1)
    elif re.match("->query", sqlStr, re.IGNORECASE | re.S):
        pos = 1
        sqlStr = re.match("->query\s*(.+)", sqlStr, re.IGNORECASE | re.S).group(1)
    elif re.match("mysql_query", sqlStr, re.IGNORECASE | re.S):
        pos = 1
        sqlStr = re.match("mysql_query\s*(.+)", sqlStr, re.IGNORECASE | re.S).group(1)
    elif re.match("query", sqlStr, re.IGNORECASE | re.S):
        pos = 1
        sqlStr = re.match("query\s*(.+)", sqlStr, re.IGNORECASE | re.S).group(1)
    # 先求sql所在区间
    stack = ['(']
    quoteFlag = ""
    for i, ele in enumerate(sqlStr[1:]):
        if ele == '(' and not quoteFlag:
            stack.append(ele)
        elif (ele == "\"" or ele == "'") and not quoteFlag:
            quoteFlag = ele
        elif quoteFlag and ele == quoteFlag:
            quoteFlag = ""
        elif ele == ")" and not quoteFlag:
            stack.pop()
            if len(stack) == 0:
                sqlStr = sqlStr[1:i + 1]
                break
    # 再划分参数区间
    interval = []
    begin = 0
    quoteFlag = ""
    for i, ele in enumerate(sqlStr):
        if (ele == "\"" or ele == "'") and not quoteFlag:
            quoteFlag = ele
        elif quoteFlag and ele == quoteFlag:
            quoteFlag = ""
        elif ele == ',' and not quoteFlag:
            interval.append(sqlStr[begin:i])
            begin = i
    if len(interval) == 0:
        interval.append(sqlStr[begin:])
    else:
        interval.append(sqlStr[begin + 1:])
    return interval[pos - 1].strip()


# 获取实际的SQL
def getActualSql(text, SQLPositionStack, sql):
    tar = sql
    # 判断是否传入的是变量
    isFind = False
    if sql.startswith("$"):
        for idx in range(len(SQLPositionStack) - 2, -1, -1):
            tmp = text[SQLPositionStack[idx]: SQLPositionStack[idx + 1]]
            if re.search("\$" + sql[1:] + "\s*?=(.+?);[\n\t\s]", tmp, re.IGNORECASE | re.S):
                tar = re.search("\$" + sql[1:] + "\s*?=(.+?);[\n\t\s]", tmp, re.IGNORECASE | re.S).group(1).strip()
                if re.search("\$" + sql[1:] + "\s*?\.=(.+?);[\n\t\s]", tmp, re.IGNORECASE | re.S):
                    for i in re.findall("\$" + sql[1:] + "\s*?\.=(.+?);[\n\t\s]", tmp, re.IGNORECASE | re.S):
                        tar += " . "
                        tar += i.strip()
                isFind = True
            if isFind:
                break
    initSQL = tar
    print("初始SQL语句：", tar)
    # 转换SQL语句
    tar = tar.strip()
    quoteFlag = ""
    splitIdx = [-1]
    for i, ele in enumerate(tar):
        if (ele == "\"" or ele == "'") and not quoteFlag:
            quoteFlag = ele
        elif quoteFlag and ele == quoteFlag:
            quoteFlag = ""
        elif not quoteFlag and ele == ".":
            splitIdx.append(i)
    newTar = []
    for i in range(len(splitIdx)):
        if i < len(splitIdx) - 1:
            curr = tar[splitIdx[i] + 1:splitIdx[i + 1]].strip()
        else:
            curr = tar[splitIdx[i] + 1:].strip()
        if curr[0] == curr[-1] and (curr[0] == "\"" or curr[0] == "'"):
            if curr[1] == "\"" or curr[1] == "'" or curr[1] == '.':
                curr = curr
            else:
                curr = curr[0] + " " + curr[1:]
        # print(curr)
        newTar.append(curr)
    return initSQL, ' . '.join(newTar)


# 获取占位符填充的SQL语句
def getCharSQL(sql):
    varStack = []
    sql = re.match("sprintf\((.+)\)", sql, re.I | re.S).group(1)
    quoteFlag = ""
    begin = -1
    for i, ele in enumerate(sql):
        if (ele == "\"" or ele == "'") and not quoteFlag:
            quoteFlag = ele
        elif quoteFlag and ele == quoteFlag:
            quoteFlag = ""
        elif ele == ',' and not quoteFlag:
            varStack.append(sql[begin + 1:i].strip())
            begin = i
    varStack.append(sql[begin + 1:].strip())

    return varStack[0], varStack[1:]


# 修改源文件，对SQL进行定位
# 头标记：[[existT_ψ1_ψ2_..._φ ]]
# 句内标记：
def updateFile(fileName):
    var_list = []
    actual_sql_list = []
    initText = ""
    try:
        with open(fileName, encoding="utf-8") as f:
            initText = f.read()  # 整个文件
            # 1.定位SQL语句
            regx = r"mysqli_query\s*\(.+?\).*?;[\n\t\s]|mysql_query\s*\(.+?\).*?;[\n\t\s]|->query\s*\(.+?\).*?;[\n\t\s]|execute\s*\(.+?\).*?;[\n\t\s]|mysqli_multi_query\s*\(.+?\).*?;[\n\t\s]|->sql_query\s*\(.+?\).*?;[\n\t\s]|query\s*\(.+?\).*?;[\n\t\s]|exec\s*\(.+?\).*?;[\n\t\s]"
            res = re.finditer(regx, initText, re.IGNORECASE | re.S)
            # 遍历当前页面所有SQL语句  select delete:0  update:1  call:2  insert:3
            for sql in res:
                print(sql)
                low = sql.span()[0]
                high = sql.span()[1]
                sql = initText[low:high + 1]
                print("当前文件:", fileName)
                if len(sql) <= 10000:
                    print("源码SQL形式", sql, '\n')
                    sql = obtainSQL(sql).strip()
                    print(f"取出的var或stmt:{sql}", '\n')
                    # 判断是否是变量的形式
                    if sql.startswith("$"):
                        # 存储到目标变量列表中，便于PHP-Parser的解析
                        var_list.append(sql)
                    else:
                        # 是真实的SQL语句，进行特殊标记
                        if "[[stmt_is_marked_by_security]]" not in sql:
                            mark_sql = "'[[stmt_is_marked_by_security]]'." + sql + ".'[[stmt_is_marked_by_security]]'"
                            actual_sql_list.append((sql, mark_sql))
                        # with open(r"C:\Users\ming\Desktop\sql.txt", "a+")as file:
                        #     file.write(sql+"\n")
        with open(fileName, 'r', encoding="utf-8") as f:
            initText = f.read()  # 整个文件
            actual_sql_list = list(set(actual_sql_list))
            for ele in actual_sql_list:
                initText = initText.replace(ele[0], ele[1])
        with open(fileName, 'w', encoding="utf-8") as f:
            f.write(initText)
        var_list = list(set(var_list))  # 去重，当前页面的元素
        for var_name in var_list:
            #command = f"php C:/Users/ming/vendor/nikic/php-parser/bin/php-parse-1 -varName={var_name[1:]} -mode=2 {fileName}"
            command = f"php C:/Users/admin/Desktop/vendor/nikic/php-parser/bin/php-parse-1 -varName={var_name[1:]} -mode=2 {fileName}"
            po = os.popen(command)
            print(po.buffer.read().decode(encoding='utf-8', errors='ignore'))
            po.close()
    except Exception as e:
        print("------出现错误------")
        print(e)
        print('行号', e.__traceback__.tb_lineno)
        print("------出现错误------")


def add_keyword_flags(sql, inner):
    keys = ['where\s', 'and\s', '\sor\s', 'group by\s', 'order by\s', 'having\s', 'limit\s', 'set\s',
            '\svalues', "between\s", "like\s", "\s\|\|\s", "\sis\s" , "\s\&\&\s"] # 暂时未考虑in关键字
    for ele in keys:
        if ele == "\svalues":
            sql = re.sub(ele, " " + inner + "_values_" + inner + " ", sql, flags=re.IGNORECASE | re.S)
        elif ele == "\s\|\|\s":
            sql = re.sub(ele, " " + inner + "_||_" + inner + " ", sql, flags=re.IGNORECASE | re.S)
        elif ele == "\s\&\&\s":
            sql = re.sub(ele, " " + inner + "_&&_" + inner + " ", sql, flags=re.IGNORECASE | re.S)
        elif ele == "\sis\s" or ele == "\sor\s":
            sql = re.sub(ele, " " + inner + "_" + ele[2:-2] + "_" + inner + " ", sql, flags=re.IGNORECASE | re.S)
        else:
            sql = re.sub(ele, " " + inner + "_" + ele[:-2] + "_" + inner + " ", sql, flags=re.IGNORECASE | re.S)
    operator = ['>=', '<=', '<>', '>', '<', '=', '!=']
    operator_ = ['>=', '<=', '<>', '[^<-]>[^=]', '<[^>=]', '[^><!]=', '!=']
    for i, ele in enumerate(operator_):
        if ele == '[^<-]>[^=]':
            p = list(set(re.findall(ele, sql, flags=re.IGNORECASE | re.S)))
            for m in p:
                sql = sql.replace(m, m[0] + " " + inner + "_" + operator[i] + "_" + inner + " " + m[-1])
        elif ele == '<[^>=]':
            p = list(set(re.findall(ele, sql, flags=re.IGNORECASE | re.S)))
            for m in p:
                sql = sql.replace(m, " " + inner + "_" + operator[i] + "_" + inner + " " + m[1])
        elif ele == '[^><!]=':
            p = list(set(re.findall(ele, sql, flags=re.IGNORECASE | re.S)))
            for m in p:
                sql = sql.replace(m, m[0] + " " + inner + "_" + operator[i] + "_" + inner + " ")
        else:
            sql = re.sub(ele, " " + inner + "_" + operator[i] + "_" + inner + " ", sql, flags=re.IGNORECASE | re.S)
    sql = sql.replace(",", " " + inner + "_,_" + inner + " ")
    return sql


def extract_var_stmts(var_name, text):
    stmts = re.findall("\$" + var_name[1:] + "\s*?[\.]*\=(.+?);", text, re.S|re.IGNORECASE)
    if len(stmts) == 0:
        return '', '1'
    else:
        first = stmts[0]  # 只判断第一个元素
        if "$_GET" in first or "$_POST" in first or "$_REQUEST" in first or "$this" in first:
            return "", '1'
        elif "$_COOKIE" in first or "$_SESSION" in first or "$_FILES" in first:
            return "", '2'
        elif re.search("fetch_", first, re.IGNORECASE|re.S):
            return "", '2'  # 来源于数据库
        else:  # 是动态类型拼接的语句，属于SQL语句的一部分
            # 重复执行添加标识符、得到变量
            return var_name, '1'


def get_var_type(all_var_name, var_area, text, inner):
    """
    :param var_area: 变量范围
    :return:
    1.使用正则表达式提取变量名
    2.变量名 若为$_GET $_POST $_Request .. $COOKIE $_SESSION  直接变量
    3.若不包含$ 则证明是常量
    4.若为其他名字 如$data，则需要判断是获取$_GET $_POST类型，
    """
    var_type = []
    for var in var_area:
        try:
            var_name = re.search("(\$[\_a-zA-Z][a-zA-Z0-9\_]*)|([\_a-zA-Z][a-zA-Z0-9\_]*\(.*?\))", var, re.S|re.IGNORECASE).group(0)
            if var_name.startswith("$"):
                if var_name in all_var_name:
                    all_var_name.remove(var_name)
                # 是变量形式
                if var_name == "$_POST" or var_name == "$_GET" or var_name == "$_REQUEST" or var_name == "$this":
                    var_type.append('1')
                elif var_name == "$_COOKIE" or var_name == "$_SESSION" or var_name == "$_FILES":
                    var_type.append('2')
                else:
                    # 提取上文出现变量的语句
                    a, b = extract_var_stmts(var_name, text)
                    if a:
                        all_var_name.append(a)
                    var_type.append(b)
            else:
                # 是函数形式，当成一阶SQL注入处理
                var_type.append('1')
        except:
            var_type.append('0')
    other_stmt = []
    if len(all_var_name) > 0:
        print("====-----====")
        # 不考虑数据源了，直接添加标识符
        for var_name in all_var_name:
            stmts = re.findall("\$" + var_name[1:] + "\s*?[\.]*\=([^\n]+?);", text, re.S|re.IGNORECASE)
            for stmt in stmts:
                new_stmt = stmt.strip()
                if (new_stmt[0] == '"' or new_stmt[0] == "'") and inner not in new_stmt:
                    print("varname", var_name)
                    print("stmt", stmt)
                    new_stmt = stmt.replace(",", " " + inner + "_,_" + inner + " ")
                    new_stmt = add_keyword_flags(new_stmt, inner)
                    other_stmt.append([stmt, new_stmt])
    return var_type, other_stmt


def matchOperator(sql, inner, text):
    # 首先匹配所有标识符
    pattern = re.compile(inner+"_.+?_"+inner)
    flags = pattern.finditer(sql)
    if any(flags):  # 判断迭代器是否非空
        operator = ['>=', '<=', '<>', '>', '<', '=', '!=', 'like', 'is', "group by", 'order by', 'limit']
        targetPos = []
        flags = pattern.finditer(sql)
        for f in flags:
            for op in operator:
                if f.group(0) == inner + "_" + op + "_" + inner:
                    c_type = 0
                    if op == "group by" or op == "order by" or op == "limit":  # 将这些字段的数据源信息置为常量
                        c_type = 1
                    targetPos.append([c_type, f.span()])
                    break
        # 提取变量大致范围
        if len(targetPos) == 0:
            all_var_name = re.findall("\$[a-zA-Z\_][a-zA-Z0-9\_]*", sql, re.IGNORECASE | re.S)
            # 确定变量的类型
            _, other_stmt = get_var_type(all_var_name, [], text, inner)
            return "", other_stmt
        var_area = []
        for i in range(len(targetPos)-1):
            if targetPos[i][0] == 0:
                var_area.append(sql[targetPos[i][1][1]:targetPos[i+1][1][0]])
            else:
                var_area.append("constant")
        # 最后一个变量范围
        if targetPos[-1][0] == 1:
            var_area.append("constant")
        else:
            var_area.append(sql[targetPos[-1][1][1]:])
        # 提取出所有的变量名，用于处理通过变量构成的SQL语句
        all_var_name = re.findall("\$[a-zA-Z\_][a-zA-Z0-9\_]*", sql, re.IGNORECASE | re.S)
        # 确定变量的类型
        var_type, other_stmt = get_var_type(all_var_name, var_area, text, inner)
        return "_".join(var_type), other_stmt
    else:
        return "", ""


def addIdentifier(fileName):
    global count
    # 生成句内标记的明文和私钥
    init = 'abc'
    pKey = "adf123"
    # 生成内标记
    inner = generateInnerFlag(init=init, pKey=pKey)
    with open(fileName, encoding='utf-8') as file:
        text = file.read()
        update_text = text
        # 提取SQL语句
        pattern = r"\'\[\[stmt_is_marked_by_security\]\]\'\.(.+?)\.\'\[\[stmt_is_marked_by_security\]\]\'"
        sqls = re.findall(pattern, text, re.S)
        # 去除特殊标识符 [[stmt_is_marked_by_security]]  写入文件
        text = text.replace("'[[stmt_is_marked_by_security]]'.", "").replace(".'[[stmt_is_marked_by_security]]'", "")
        with open(fileName, 'w', encoding='utf-8') as file:
            file.write(text)
        sqls = list(set(sqls))
        for sql in sqls:
            try:
                print(f"初始SQL：{sql}")
                initSQL = sql
                sql = re.sub(r'\\t|\\n|\\r',' ',sql)
                # 需要考虑多条SQL的形式，先对 ; 添加标识符，当然可以自定义
                sql = sql.replace(";", " mmmm_;_mmmm ")
                # 处理sprintf的语句，PHP中使用占位符格式化的方式，可扩展，这里只简单适配现有的测试web
                sprintfSQL = ""
                if sql.startswith("sprintf"):  # 使用占位符的形式构建SQL语句
                    sprintfSQL = sql
                    sql, operSplit1 = getCharSQL(sql)
                    tmpsql = sql
                start = sql[0]
                sql = sql[1:]
                for idx, c_sql in enumerate(sql.split(" mmmm_;_mmmm ")):
                    old_sql = c_sql
                    if idx > 0:
                        c_sql = c_sql.strip()  # 去除空白
                    # 判断是否是 insert into的语句
                    if re.search("insert\s+?into\s+?.+?values", c_sql, re.IGNORECASE|re.S):
                        # 提取values部分的数据
                        values = re.search("insert\s+?into\s+?.+?values\s*?(\(.+\))", c_sql, re.IGNORECASE|re.S).group(1)
                        # print(values)
                        values_list = values.split(",")
                        if len(values_list) > 1:
                            value_type, _ = get_var_type([], values_list, text, inner)
                            flag = "exist_" + "_".join(value_type)
                            new_values = values.replace(",", " " + inner + "_,_" + inner + " ")
                            c_sql = c_sql.replace(values, new_values)
                            c_sql = re.sub("\svalues", " " + inner + "_values_" + inner + " ", c_sql, flags=re.IGNORECASE|re.S)
                        else:
                            c_sql = re.sub("\svalues", " " + inner + "_values_" + inner + " ", c_sql, flags=re.IGNORECASE|re.S)
                            var_names = re.findall("\$[\_a-zA-Z][\_a-zA-Z0-9]*", c_sql, re.IGNORECASE|re.S)
                            for name in var_names:
                                stmts = re.findall("\$" + name[1:] + "\s*?[\.]*\=([^\n]+?);", update_text, re.S|re.IGNORECASE)
                                for stmt in stmts:
                                    if inner not in stmt:
                                        update_text = update_text.replace(stmt, new_stmt.replace(",", " " + inner + "_,_" + inner + " ").
                                                                      replace("=", " " + inner + "_=_" + inner + " "), 1)
                            flag = "exist_1"  # 对于常量-0 一阶-1 二阶-2 特殊-1(默认策略)
                    elif re.search("insert\s+?into\s+?.+?set", c_sql, re.IGNORECASE|re.S) and "=" not in c_sql:
                        # 提取变量
                        var_names = re.findall("\$[\_a-zA-Z][\_a-zA-Z0-9]*", c_sql, re.IGNORECASE|re.S)
                        for name in var_names:
                            stmts = re.findall("\$" + name[1:] + "\s*?[\.]*\=([^\n]+?);", update_text, re.S|re.IGNORECASE)
                            for stmt in stmts:
                                if inner not in stmt:
                                    new_stmt = re.sub("\sset\s", " " + inner + "_set_" + inner + " ", stmt, flags=re.IGNORECASE|re.S)
                                    update_text = update_text.replace(stmt, new_stmt.replace(",", " " + inner + "_,_" + inner + " ").
                                                        replace("=", " " + inner + "_=_" + inner + " "), 1)
                        c_sql = re.sub("\sset\s", " " + inner + "_set_" + inner + " ", c_sql, flags=re.IGNORECASE|re.S)
                        flag = "exist_1"  # 对于常量-0 一阶-1 二阶-2 特殊-1(默认策略)
                    elif re.search("update\s+?.+?", c_sql,  re.IGNORECASE|re.S) or re.search("delete\s+?.+?", c_sql,  re.IGNORECASE|re.S) or \
                         re.search("select\s+?.+?", c_sql,  re.IGNORECASE|re.S) or re.search("insert\s+?.+?", c_sql,  re.IGNORECASE|re.S) or idx == 0:
                        # 由于存在动态类型构建的SQL语句，先无差别的对关键字添加标识符
                        c_sql = add_keyword_flags(c_sql, inner)
                        # 匹配operator = != <> ......
                        data_source, other_stmt = matchOperator(c_sql, inner, text)
                        print("=====", other_stmt)
                        if data_source != "":
                            flag = "exist_" + data_source
                        else:
                            flag = "exist"
                        if len(other_stmt) > 0:
                            print("正在处理额外的SQL语句......\n")
                            # 存在额外的SQL语句
                            other_stmt = [list(t) for t in set(tuple(_) for _ in other_stmt)]
                            for stmt in other_stmt:
                                update_text = update_text.replace(stmt[0], stmt[1])
                    else:
                        continue
                    flag += "_" + init
                    if start == "'" or start == '"':
                        sql = sql.replace(old_sql, "[[" + flag + "]] " + c_sql)  # 添加加密的初始字符串
                # 添加标记
                # 在此处添加文件位置信息
                file_name = fileName[27:].replace("\\","_").replace(".","_").replace("-","_")
                #file_name = fileName[33:].replace("\\","_").replace(".","_").replace("-","_")
                fileMark = "23ertgytse4tyuidhf7894h"+file_name + "343hggdsfylgfdj435435"
                if sprintfSQL:
                    sql = sprintfSQL.replace(tmpsql, start + fileMark+sql)
                else:
                    sql = start + fileMark+sql

                print("添加标识符后：", sql, '\n')
                update_text = update_text.replace(initSQL, sql)
                print("SQL更新完毕")
                print("--" * 25 + "\n")
            except Exception as e:
                print(e)
                print(e.__traceback__.tb_frame.f_globals["__file__"])   # 发生异常所在的文件
                print(e.__traceback__.tb_lineno)                        # 发生异常所在的行数
    with open(fileName, 'w', encoding='utf-8') as file:
        update_text = update_text.replace("'[[stmt_is_marked_by_security]]'.", " ").replace(".'[[stmt_is_marked_by_security]]'", " ")
        file.write(update_text)


# 主函数，程序的入口
if __name__ == '__main__':
    basedir = r"C:\Users\admin\Desktop\st\bwapp1"
    # basedir = r"C:\Users\ming\Desktop\test"
    getFileName(basedir)



